package com.nicksdesign.liquidglass

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(32), dp(24), dp(32))
            setBackgroundColor(Color.rgb(15, 19, 29))
        }
        val title = TextView(this).apply {
            text = "Liquid Glass"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Un'interfaccia ispirata al vetro di iOS 26"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(28))
        }
        val permission = Button(this).apply {
            text = "1 · Attiva autorizzazione overlay"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    text = "Autorizzazione già attiva"
                }
            }
        }
        val start = Button(this).apply {
            text = "2 · Avvia Liquid Glass"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    val i = Intent(this@MainActivity, GlassOverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                    text = "Liquid Glass attivo"
                }
            }
        }
        val info = TextView(this).apply {
            text = "Dopo l'avvio compare una piccola capsula sul bordo dello schermo. Tocca la capsula per aprire il pannello Liquid Glass sopra le altre app. Per mantenerlo attivo, consenti l'esecuzione in background nelle impostazioni della batteria."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(24), 0, 0)
        }
        layout.addView(title, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        layout.addView(subtitle)
        layout.addView(permission)
        layout.addView(start)
        layout.addView(info)
        setContentView(layout)
    }
}
