package com.nicksdesign.liquidglass

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.*
import android.view.WindowManager
import android.widget.*
import android.media.AudioManager
import android.hardware.camera2.CameraManager

class GlassOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private val channelId = "liquid_glass_service"
    private fun dp(v: Int) = (resources.displayMetrics.density * v).toInt()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId)
                .setContentTitle("Liquid Glass attivo")
                .setContentText("Tocca la capsula sullo schermo per aprire il pannello")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true).build()
        else Notification.Builder(this)
            .setContentTitle("Liquid Glass attivo")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(7, notification)
        showBubble()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Liquid Glass", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun glassDrawable(radius: Float = 34f): GradientDrawable =
        GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.argb(205, 235, 245, 255), Color.argb(105, 110, 140, 175), Color.argb(155, 25, 35, 55))
        ).apply {
            cornerRadius = dp(radius.toInt()).toFloat()
            setStroke(dp(1), Color.argb(150, 255, 255, 255))
        }

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "◈"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = glassDrawable(28f)
            elevation = dp(12).toFloat()
            setOnClickListener { showPanel() }
        }
        val p = WindowManager.LayoutParams(dp(54), dp(54), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            x = dp(8)
        }
        b.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; startX=p.x; startY=p.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-downX).toInt(); val dy=(e.rawY-downY).toInt()
                        if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>dp(6)) moved=true
                        p.x=(startX-dx).coerceAtLeast(0); p.y=startY+dy
                        wm.updateViewLayout(b,p); return true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) showPanel(); return true }
                }
                return false
            }
        })
        bubble = b
        wm.addView(b, p)
    }

    private fun showPanel() {
        if (panel != null) return
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(95, 0, 0, 0))
            setOnClickListener { closePanel() }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(22))
            background = glassDrawable(32f)
            elevation = dp(24).toFloat()
            setOnClickListener { }
        }
        val header = TextView(this).apply {
            text = "Liquid Glass"
            textSize = 25f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(16))
        }
        card.addView(header)
        val clock = TextView(this).apply {
            text = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            textSize = 48f; setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(18))
        }
        card.addView(clock)
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(actionButton("Volume −") { volume(false) }, LinearLayout.LayoutParams(0, dp(58), 1f))
        row1.addView(space())
        row1.addView(actionButton("Volume +") { volume(true) }, LinearLayout.LayoutParams(0, dp(58), 1f))
        card.addView(row1)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(actionButton("Torcia") { toggleTorch() }, LinearLayout.LayoutParams(0, dp(58), 1f))
        row2.addView(space())
        row2.addView(actionButton("Impostazioni") {
            val i = Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i); closePanel()
        }, LinearLayout.LayoutParams(0, dp(58), 1f))
        card.addView(row2)
        val close = TextView(this).apply {
            text = "Chiudi"
            gravity = Gravity.CENTER
            textSize = 15f; setTextColor(Color.WHITE)
            setPadding(0, dp(18), 0, dp(4))
            setOnClickListener { closePanel() }
        }
        card.addView(close)
        val cardParams = FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply {
            leftMargin=dp(20); rightMargin=dp(20)
        }
        root.addView(card, cardParams)
        val lp = WindowManager.LayoutParams(-1, -1, overlayType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_DIM_BEHIND,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            dimAmount = 0.35f
            if (Build.VERSION.SDK_INT >= 31) {
                flags = flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
                blurBehindRadius = dp(28)
            }
        }
        panel = root
        try { wm.addView(root, lp) } catch (_: Exception) { panel = null }
    }

    private fun space() = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(10), 1) }

    private fun actionButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; textSize = 14f
        setTextColor(Color.WHITE); background = glassDrawable(18f)
        setOnClickListener { action() }
        setPadding(dp(5), dp(8), dp(5), dp(8))
    }

    private fun volume(up: Boolean) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI)
    }

    private var torchOn = false
    private fun toggleTorch() {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it)
                .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id != null) { torchOn = !torchOn; cm.setTorchMode(id, torchOn) }
        } catch (_: Exception) {
            Toast.makeText(this, "Torcia non disponibile", Toast.LENGTH_SHORT).show()
        }
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
