# Liquid Glass for Android

Progetto iniziale Android nativo (Kotlin), pensato per Android 8.0+ e testabile anche su Redmi Note 14 4G.

## Cosa include
- Pulsante flottante sempre disponibile sopra le altre app.
- Pannello overlay con aspetto vetro traslucido.
- Sfocatura dietro al pannello sui dispositivi/finestre che supportano `FLAG_BLUR_BEHIND` (Android 12+).
- Controlli volume, torcia e apertura Impostazioni.
- Servizio in primo piano con notifica persistente.

## Apertura
1. Installa Android Studio.
2. Apri la cartella `LiquidGlassAndroid`.
3. Attendi la sincronizzazione Gradle.
4. Avvia l'app su un telefono Android.
5. Premi **Attiva autorizzazione overlay** e abilita "Mostra sopra altre app".
6. Torna nell'app e premi **Avvia Liquid Glass**.

## Limiti Android
Questa app aggiunge un overlay richiamabile sopra le altre app. Non può cambiare direttamente i pulsanti, le schermate o gli elementi interni di app di terze parti, né sostituire integralmente la barra di stato o il pannello rapido di sistema. Il blur dipende dal supporto del produttore e dalle impostazioni di sistema. Per un'esperienza persistente, abilita l'avvio automatico e consenti l'attività in background nelle impostazioni batteria del telefono.

## Prossimi miglioramenti
- Pannello configurabile e temi chiaro/scuro.
- Gestione luminosità con autorizzazione dedicata.
- Notifiche personalizzate (con autorizzazioni e limiti Android).
- Test specifici MIUI/HyperOS.
